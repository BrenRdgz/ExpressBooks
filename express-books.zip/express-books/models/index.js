const Book = require('./Book');

module.exports = {
  Book,
};
