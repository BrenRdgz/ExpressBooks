const BookResources = require('./bookResources');

module.exports = {
  BookResources,
};
