const BookControllers = require('./bookControllers');

module.exports = {
  BookControllers,
};
